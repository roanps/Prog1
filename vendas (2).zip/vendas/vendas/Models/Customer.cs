﻿using System.ComponentModel.DataAnnotations;

namespace vendas.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Address? HomeAddress { get; set; }
        public Address? WorkAddress { get; set; }

        public bool Validate()
        {
            bool isValid = true;

            isValid = (this.Id > 0) &&
                      !string.IsNullOrWhiteSpace(Name) &&
                      HomeAddress != null &&
                      WorkAddress != null;

            return isValid; ;
        }
    
    }
}
