﻿using System.ComponentModel.DataAnnotations;

namespace vendas.Models
{
    public class Order
    {
        #region Atributos
        public int Id { get; set; }
        public Customer? Customer { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public Address? ShippingAddress { get; set; }
        public List<OrderItem>? OrderItems { get; set; }
        #endregion
        
        public Order()
        {
            OrderDate = DateTime.Now;
            OrderItems = new List<OrderItem>();
        }

        public Order(int orderId) : this()
        {
            this.Id = orderId;
        }
        public bool Validate()
        {
            bool isValid = true;

            isValid = (this.Id > 0) &&
                      Customer != null &&
                      OrderDate != null &&
                      ShippingAddress != null &&
                      (OrderItems != null && OrderItems.Any());

            return isValid; ;
        }

    }
}
