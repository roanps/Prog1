﻿using System.ComponentModel.DataAnnotations;

namespace vendas.Models
{
    public class OrderItem
    {
        public int Id { get; set; }  
        public Product? Product { get; set; }
        public double Quantity { get; set; }       
        public double PurchasePrice { get; set; }

        public bool Validate()
        {
            bool isValid = true;

            double quantity = 10; //varuiveis locais CamelCase, Quantity  

            isValid = (this.Id > 0) &&
                      (this.Quantity > 0) &&
                      (PurchasePrice > 0) &&
                      Product != null;

            return isValid;
        }
    }
}
