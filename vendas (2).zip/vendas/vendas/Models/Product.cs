﻿using System.ComponentModel.DataAnnotations;

namespace vendas.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public double CurrentPrice { get; set; }

        public Product()
        {

        }
        public Product(int productId)
        {
            this.Id = productId;
        }
        public bool Validate()
        {
            bool isValid = true;

            isValid = (this.Id > 0) &&
                      !string.IsNullOrWhiteSpace(ProductName) &&
                      !string.IsNullOrWhiteSpace(Description) &&
                      CurrentPrice >0;

            return isValid;
        }

    }
}
